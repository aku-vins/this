# Sonic 
a very helpfull discord bot

