module.exports = {
	prefix: "sonic",
	owners: ["727110220400033865"],
	token: "NzQ3NDMzNDM4NjI5MzMwOTk2.X0Ozog.Qud23zO7n3ZZoU4YB35bWTUKSGk",
};