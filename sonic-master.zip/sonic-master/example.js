module.exports.run = async (bot, message, args) => {



};


module.exports.help = {
  name: "",
  description: "",
  usage: "",
  category: "",
  aliases: [""]
};